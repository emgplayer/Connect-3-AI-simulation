#include <stdio.h>
#include <stdlib.h>
#define MIN -10000000
#define MAX 10000000
#define MAX_CVOROVA 20000
void initTabla(char tabla[4][4])
{
    for(int i = 0; i < 4; i++)
    {
        for(int j = 0; j < 4; j++)
        {
            tabla[i][j] = '.';
        }
    }
}
void printTabla(char tabla[4][4])
{
    for(int i = 0; i < 4; i++)
    {
        for(int j = 0; j < 4; j++)
        {
            printf("%c ", tabla[i][j]);
        }
        printf("\n");
    }
}
int validanPotez(int kolona, char tabla[4][4])
{
    if(kolona < 0 || kolona > 3)
    {
        return 0;
    }
    if(tabla[0][kolona] != '.')
        return 0;
    return 1;
}
int odigrajPotez(int kolona, char igrac, char tabla[4][4])
{
    for(int i = 3; i >= 0; i--)
    {
        if (tabla[i][kolona] == '.')
        {
            tabla[i][kolona] = igrac;
            return 1;
        }
    }
    return 0;
}
int proveriPobedu(char igrac, char tabla[4][4])
{
    for(int i = 0; i < 4; i++)
    {
        for(int j = 0; j <= 1; j++)
        {
            if(tabla[i][j] == igrac && tabla[i][j+1] == igrac && tabla[i][j+2] == igrac)
                return 1;
        }
    }
    for(int j = 0; j < 4; j++)
    {
        for(int i = 0; i <= 1; i++)
        {
            if(tabla[i][j] == igrac && tabla[i+1][j] == igrac && tabla[i+2][j] == igrac)
                return 1;
        }
    }
    for(int i = 0; i <= 1; i++)
    {
        for(int j = 0; j <= 1; j++)
        {
            if(tabla[i][j] == igrac && tabla[i+1][j+1] == igrac && tabla[i+2][j+2] == igrac)
                return 1;
        }
    }
    for(int i = 0; i <= 1; i++)
    {
        for(int j = 2; j <= 3; j++)
        {
            if(tabla[i][j] == igrac && tabla[i+1][j-1] == igrac && tabla[i+2][j-2] == igrac)
                return 1;
        }
    }
    return 0;
}
int punaTabla(char tabla[4][4])
{
    for(int i = 0; i < 4; i++)
    {
        for(int j = 0; j < 4; j++)
        {
            if(tabla[i][j] == '.')
                return 0;
        }
    }
    return 1;
}
void ucitajTabluIzFajla(char* imeFajla, char tabla[4][4])
{
    FILE* f = fopen(imeFajla, "r");

    if(f == NULL) {
        printf("Greska pri otvaranju fajla\n");
        return;
    }

    for(int i = 0; i < 4; i++) {
        for(int j = 0; j < 4; j++) {
            fscanf(f, "%c ", &tabla[i][j]);
        }
    }

    fclose(f);
}
typedef struct Cvor {
    char tabla[4][4];
    char igrac;
    int vrednost;
    int dubina;
    struct Cvor* deca[4];
    int brojDece;
} Cvor;
typedef struct {
    Cvor* niz[MAX_CVOROVA];
    int front, rear;
} Queue;

void initQueue(Queue* q) {
    q->front = q->rear = 0;
}

void enqueue(Queue* q, Cvor* c) {
    q->niz[q->rear++] = c;
}

Cvor* dequeue(Queue* q) {
    return q->niz[q->front++];
}

int empty(Queue* q) {
    return q->front == q->rear;
}
void kopiranje(char source[4][4], char dest[4][4])
{
    for(int i = 0; i < 4; i++)
        for(int j = 0; j < 4; j++)
            dest[i][j] = source[i][j];
}
Cvor* napraviCvor(char tabla[4][4], char igrac)
{
    Cvor* novi = (Cvor*)malloc(sizeof(Cvor));
    kopiranje(tabla, novi->tabla);
    novi->igrac = igrac;
    novi->vrednost = 0;
    novi->brojDece = 0;
    novi->dubina = 0;
    for(int i = 0; i < 4; i++)
        novi->deca[i] = NULL;
    return novi;
}
void generisiDecu(Cvor* cvor, Queue* q)
{
    for(int col = 0; col < 4; col++)
    {

        if(cvor->tabla[0][col] == '.')
        {
            char novaTabla[4][4];
            kopiranje(cvor->tabla, novaTabla);
            for(int i = 3; i >= 0; i--)
            {
                if(novaTabla[i][col] == '.')
                {
                    novaTabla[i][col] = cvor->igrac;
                    break;
                }
            }
            char sledeci;
            if(cvor->igrac == 'X')
                sledeci = 'O';
            else
                sledeci = 'X';
            Cvor* dete = napraviCvor(novaTabla, sledeci);
            dete->dubina = cvor->dubina + 1;
            cvor->deca[cvor->brojDece++] = dete;
            enqueue(q, dete);
        }
    }
}
void napraviStablo(Cvor* koren, int maxDubina) {
    Queue q;
    initQueue(&q);

    enqueue(&q, koren);

    while(!empty(&q)) {
        Cvor* trenutni = dequeue(&q);

        if(trenutni->dubina == maxDubina)
            continue;

        if(proveriPobedu('X', trenutni->tabla) ||
           proveriPobedu('O', trenutni->tabla) ||
           punaTabla(trenutni->tabla))
            continue;

        generisiDecu(trenutni, &q);
    }
}
int heuristika(char tabla[4][4])
{
    int VC = 0, VP = 0;
    for(int i = 0; i < 4; i++)
    {
        for(int j = 1; j <= 2; j++)
        {
            if(tabla[i][j] == 'O') VC++;
            if(tabla[i][j] == 'X') VP++;
        }
    }
    for(int j = 0; j < 4; j++)
    {
        if(tabla[3][j] == 'O') VC++;
        if(tabla[3][j] == 'X') VP++;
    }
    return 5 * (VC - VP);
}
int evaluacija(Cvor* cvor)
{
    if(proveriPobedu('O', cvor->tabla))
        return 1000;

    if(proveriPobedu('X', cvor->tabla))
        return -1000;

    if(punaTabla(cvor->tabla))
        return 0;
    return heuristika(cvor->tabla);
}
int prikupiCvorove(Cvor* koren, Cvor* lista[])
{
    Queue q;
    initQueue(&q);
    enqueue(&q, koren);
    int n = 0;
    while(!empty(&q))
    {
        Cvor* t = dequeue(&q);
        lista[n++] = t;
        for(int i = 0; i < t->brojDece; i++)
            enqueue(&q, t->deca[i]);
    }
    return n;
}
void minimax(Cvor* koren)
{
    Cvor* lista[MAX_CVOROVA];
    int n = prikupiCvorove(koren, lista);
    for(int i = n - 1; i >= 0; i--)
    {
        Cvor* c = lista[i];
        if(c->brojDece == 0)
        {
            c->vrednost = evaluacija(c);
        }
        else
        {
            if(c->igrac == 'O')
            {
                int max = -10000;
                for(int j = 0; j < c->brojDece; j++)
                    if(c->deca[j]->vrednost > max)
                        max = c->deca[j]->vrednost;
                c->vrednost = max;
            }
            else
            {
                int min = 100000;
                for(int j = 0; j < c->brojDece; j++)
                    if(c->deca[j]->vrednost < min)
                        min = c->deca[j]->vrednost;
                c->vrednost = min;
            }
        }
    }
}
void LevelOrderPrint(Cvor* koren)
{
    int n = 0;
    Queue q;
    initQueue(&q);
    enqueue(&q, koren);
    while(!empty(&q))
    {
        Cvor* trenutni = dequeue(&q);
        printTabla(trenutni->tabla);
        printf("\n");
        n++;
        for(int i = 0; i < trenutni->brojDece; i++)
            enqueue(&q, trenutni->deca[i]);
    }
    printf("Broj cvorova u stablu je:%d", n);
}
int main()
{
    char tabla[4][4];
    printf("1. Prazna tabla\n2. Odredjeno stanje table\n");
    int izbor1, izbor2;
label1: printf("Vas izbor: ");scanf("%d", &izbor1);
    if(izbor1 != 1 && izbor1 != 2)
    {
        printf("\nNeispravan izbor, pokusaj ponovo");
        goto label1;
    }
    char* imeFajla;
    int potez = 0;
    switch(izbor1){
        case 1: initTabla(tabla); break;
label2: case 2: printf("Odaberite stanje izmedju 1 i 5:");
                scanf("%d", &izbor2);
                switch(izbor2){
                        case 1: imeFajla = "state_1.txt"; break;
                        case 2: imeFajla = "state_2.txt"; break;
                        case 3: imeFajla = "state_3.txt"; break;
                        case 4: imeFajla = "state_4.txt"; break;
                        case 5: imeFajla = "state_5.txt"; break;
                        default:
                            printf("Nevalidan izbor\n");
                            goto label2;
                }
                ucitajTabluIzFajla(imeFajla, tabla);
                for(int i = 0; i < 4; i++)
                    for(int j = 0; j < 4; j++)
                {
                    if(tabla[i][j] == 'X')
                        potez++;
                    if(tabla[i][j] == 'O')
                        potez--;
                }
    }
    //printTabla(tabla);
    int h;
    printf("Unesi maksimalnu dubinu: ");
    scanf("%d", &h);
    char igrac;
    if(potez)
        igrac = 'O';
    else
        igrac = 'X';

    Cvor* koren = napraviCvor(tabla, igrac);
    koren->dubina = 0;
    int first = 1;
    napraviStablo(koren, h);
    //LevelOrderPrint(koren);
    while (1)
    {
        printTabla(tabla);
        if(punaTabla(tabla))
        {
            printf("Nereseno!!!\n");
            goto end;
        }
            if(igrac == 'X')
            {
label3:         printf("Izaberite kolonu u koju hocete da stavite zeton: ");
                int c;
                scanf("%d", &c);
                if(!validanPotez(c, tabla))
                {
                    printf("Neispravan potez, pokusaj ponovo\n");
                    goto label3;
                }
                odigrajPotez(c, igrac, tabla);
                if(proveriPobedu(igrac, tabla))
                {
                    printTabla(tabla);
                    printf("Igrac X je pobedio");
                    goto end;
                }
                igrac = 'O';
            }
            else
            {
                Cvor* korenAI = napraviCvor(tabla, 'O');
                korenAI->dubina = 0;

                napraviStablo(korenAI, h);
                minimax(korenAI);
                h = 0;
                int najbolji = MIN;
                Cvor* izbor = NULL;

                for(int i = 0; i < korenAI->brojDece; i++)
                {
                    if(korenAI->deca[i]->vrednost > najbolji)
                    {
                        najbolji = korenAI->deca[i]->vrednost;
                        izbor = korenAI->deca[i];
                    }
                }

                if(izbor != NULL)
                {
                    kopiranje(izbor->tabla, tabla);
                    printf("Racunar je odigrao:\n");
                }
                else
                {
                        printf("Nema poteza iz stabla, igram nasumicno...\n");

                        int kolona = rand()%4;
                        while(!validanPotez(kolona, tabla))
                        {
                            kolona = (kolona + 1) % 4;
                        }
                        odigrajPotez(kolona, 'O', tabla);
                }
                if(proveriPobedu('O', tabla))
                {
                    printTabla(tabla);
                    printf("Igrac O je pobedio!!!");
                    goto end;
                }

                igrac = 'X';
            }
    }
end: printf("\nKraj igre");
}
